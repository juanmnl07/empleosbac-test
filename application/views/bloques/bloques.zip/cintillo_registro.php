<div class="w-section st_cintillo_registro">
    <div class="w-container ct_cintillo_registro">
    	<div class="w-row">
        	<div class="w-col w-col-8 info_registro">
                <p><span>Trabaja con nosotros</span> y ayúdanos
a mejorar<br> la vida de la Región.</p>
            </div>
            <div class="w-col w-col-4">
            	<a class="btn_registro" href="/registro">Registrar mi curriculum</a>
            </div>
        </div>
    </div>
</div>