<div class="w-section st_cintillo_puestos">
    <div class="w-container ct_cintillo_puestos">
        <div class="w-row">
            <div class="w-col w-col-9">
                <p>Somos el Grupo Financiero referente en la Región gracias a iniciativas que
                cambian realidades económicas y la excelente labor de nuestros colaboradores.<br><br>

                <span>Forma parte de los equipos que tenemos en toda la Región.</span></p>  
            </div>
            <div class="w-col w-col-3">
                <a href="/puestos">Carreras disponibles</a>
            </div>
        </div>
    </div>
</div>