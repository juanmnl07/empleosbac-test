<div class="w-section">
    <div class="w-container ct_aplicantes">
    	<?php if($listado_aplicantes == 'general'){?>
	    	<h1>Candidatos Generales</h1>
	    	<h2>Candidatos generales registrados en el sistema <span class="cant-aplicantes"><?=$total_aplicantes_registrados;?> aplicantes registrados</span></h2>
    	<?php }else{ ?>
			<h1>Personas Registradas</h1>
	    	<h2 class="titulo-puesto-administrativo"><?=$nombre_puesto_con_formato;?> <span class="cant-aplicantes"><?=$total_aplicantes_registrados;?> aplicantes registrados</span>
    	<?php } ?></h2>
    	<div class="w-col-3 listado-aplicantes-filtro">
			<div class="ct_listado-aplicantes-filtro">
    		<?php require_once 'bloques/filtrado_aplicantes.php';?>
			</div>
		</div>
		<div class="w-col-9 listado-aplicantes">
			<table width="100%" border="0" cellpadding="2" cellspacing="1" class="filtro_puestos_aplicados">
			    <thead>
			      <tr>
			          <th>Nombre</th>
			          <?php if($listado_aplicantes == 'general'){?>
				          <th>Puestos aplicados</th>			          
				          <th>Edad</th>			          
				          <th>Nacionalidad</th>
				          <th>Fecha de registro</th>
			          <?php } else { ?>
				          <th>Nivel</th>			          
				          <th>Edad</th>			          
				          <th>Cuando aplicó</th>
				          <th>Estado</th>
			          <?php }  ?>
			      </tr>
			    </thead>
			    <tbody>
			<?php foreach ($aplicantes_general as $key => $value) {
					foreach ($value as $key2 => $value2) {
						//var_export(empty($value2->field_imagen_perfil));
						$url = base_url().'/rrhh/api/users/puestos_aplicados_total/retrieve?uid_aplicante=' . (string)$value2->uid . '.xml';
				        $imagen_perfil = "/rrhh/sites/default/files/pictures/avatar-no.jpg";
				        $total = consumirServicioSinToken($url, $session_cookie);
                		//$total = (string)$total->item->expression;
                		$total = count($total->item);
				        if(!empty($value2->field_imagen_perfil)){
				        	$imagen_perfil = str_replace("public://", '', (string)$value2->field_imagen_perfil);
				        	$imagen_perfil = str_replace(".jpg", '_thumb.jpg', $imagen_perfil);
				        	$imagen_perfil = '/rrhh/sites/default/files/uploads/'.$imagen_perfil;
				        }
				        echo "<tr id='aplicante-".$value2->uid."'>";
				          echo "<td class='aplicante-nombre'><a href='/admin/aplicantes/detalle/". $value2->uid ."'><img style='width:65px;' src='$imagen_perfil'></a><a href='/admin/aplicantes/detalle/". $value2->uid ."'>".$value2->field_nombre_y_apellidos."</a></td>";
				          if($listado_aplicantes == 'general'){
					          if($total >= 1){
					          	echo "<td class='aplicante-puestos-aplicados'><a href='#' data-aplicante=" . $value2->uid . " class='ver-listado-puestos-aplicados'>" . $total . "</a><div class='listado-puestos-aplicados hidden'></div></td>";
					          }else{
					          	echo "<td class='aplicante-puestos-aplicados'>" . $total . "<div class='listado-puestos-aplicados hidden'></div></td>";
					          }
				          }else{
			          		$select = "<select id='cambiar-estado'" ." data-aplicante='".$value2->uid."' data-puesto='".$nid_puesto."'>";
			          		$option ="";
				          	foreach ($estados as $value3) {
				          		foreach ($value3->item as $value4) {
				          			$selected = '';
				          			$info = consultarEstadoAplicante((string)$value2->uid, $nid_puesto, $session_cookie);
						          	foreach ($info->item as $key5 => $value5) {
						          		$tid_estado = (string)$value5->tid;
						          		if($tid_estado == (string)$value4->tid){
						          			$selected = "selected";
						          		}
						          	}
				          			$option .= "<option value='".$value4->tid."' ". $selected.">".$value4->name."</option>";
				          		}
				          	}
				          	//buscar dentro de las opciones las seleccionadas
				          	$select = $select.$option."</select>";
				          	echo "<td>".$select."</td>";
				          }
				          echo "<td class='aplicante-nacionalidad-'><a href='#'>".$value2->field_nacionalidad."</a></td>";
				          echo "<td class='aplicante-fecha-registro'>" . $value2->created . "</td>";
				        echo "</tr>";
					}
				} ?>
			    </tbody>
			</table>

			<?php 

			
			
			$paginas_totales=(int)$aplicantes_general_metadata->total_pages;
			$pagina_actual=(int)$aplicantes_general_metadata->current_page;
			$valor_inicial=(int)$aplicantes_general_metadata->current_page-2;
			
			
			 if($listado_aplicantes == 'general'){
			 	$url_pagina = "/admin/aplicantes";
			 } else{
			 	$url_pagina = "/admin/aplicantes/por-puesto/".$nid_puesto;
			 }

			$html_paginas = obtenerPaginacion($paginas_totales, $pagina_actual, $valor_inicial, $url_pagina, $parametros_filtrado, "paginacion-admin");
			
			if ($html_paginas!= ""){?>
				<div class="paginacion-listado"><?=$html_paginas;?></div>
			<?php } ?>
 
			
		</div>


	</div>
</div>