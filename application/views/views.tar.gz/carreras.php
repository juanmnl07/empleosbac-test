<div class="w-section">
	<div class="w-container ct_carreras">
		
<h1 title="Ofertas de trabajo en Centroamérica y México">¿Dónde puedo <strong>aportar mi talento</strong>?</h1>

<h2>Tu también puedes ayudar a cambiar las realidades de toda una Región,<br> a unir a las personas y a darles herramientas para ver sus sueños hechos realidad.
<span class="linea"></span></h2>

<p>¡Somos miles de trabajadores liderando el desarrollo económico de la Región!</p>

<p>&nbsp;</p><p>&nbsp;</p>

	<?php require_once 'bloques/carreras.php';?>

	</div>
</div>


<?php require_once 'bloques/historias.php';?>