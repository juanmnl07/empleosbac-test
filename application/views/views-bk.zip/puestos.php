<div class="w-section">
	<div class="w-container">
        <h1>Puestos <strong>disponibles</strong></h1>
    </div>
</div>

<?php require_once 'bloques/filtrado_puestos.php';?>

<?php require_once 'bloques/cintillo_registro.php';?>

<?php require_once 'bloques/historias.php';?>