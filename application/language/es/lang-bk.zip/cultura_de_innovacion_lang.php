<?php
$lang['titulo'] = 'Cultura de innovación';
$lang['meta_desc'] = 'BAC Credomatic da la oportunidad a sus colaboradores de desarrollar y potenciar sus talentos, innovando y aportando ideas para alcanzar el éxito personal y profesional.';
$lang['meta_keywords'] = 'desarrollo profesional, Región, México, Centroamérica, desarrollo del talento humano,  desarrollar y potenciar talentos';
$lang['meta_title'] = 'Desarrollo profesional en la Región. Desarrollo de talento humano.';