<?php

$lang['-'] = '-';

