<?php
$lang['upload_userfile_not_set'] = 'No se puede encontrar el archivo';
$lang['upload_no_file_selected'] = 'Ningún archivo seleccionado';
$lang['upload_invalid_filetype'] = 'Tipo de archivo no válido';