<?php
$lang['titulo'] = 'Historias';
$lang['meta_desc'] = 'Conoce las inspiradoras historias de liderazgo y desarrollo profesional y personal de las personas que laboran en BAC Credomatic en toda la Región.';
$lang['meta_keywords'] = 'Liderazgo, desarrollo profesional, desarrollo personal';
$lang['meta_title'] = 'Historias de Liderazgo de colaboradores de BAC/Credomatic en la región.';