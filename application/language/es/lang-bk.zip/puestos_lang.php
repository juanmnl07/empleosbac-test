<?php
$lang['titulo'] = 'Puestos';
$lang['meta_desc'] = 'Conoce la variedad de puestos disponibles en nuestras distintas oficinas y sucursales en la región.  Aplica a un puesto hoy y forma parte de nuestra gran familia BAC.';
$lang['meta_keywords'] = '';
$lang['meta_title'] = 'Puestos de trabajo en México y Centroamérica';