<?php
$lang['titulo'] = 'Carreras';
$lang['meta_desc'] = 'En BAC Credomatic existen muchos puestos en distintas carreras donde puedes aportar tu talento y alcanzar tu crecimiento profesional.  Consulta sobre nuestras ofertas de trabajo.';
$lang['meta_keywords'] = 'Ofertas de trabajo, crecimiento profesional, aportar talento, Región, México, Centroamérica';
$lang['meta_title'] = 'Ofertas de trabajo, crecimiento profesional en Centroamérica y México.';