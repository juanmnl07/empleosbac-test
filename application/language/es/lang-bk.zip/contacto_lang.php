<?php
$lang['titulo'] = 'Contáctanos';
$lang['meta_desc'] = 'Regístrate con BAC/Credomatic y envíanos tu currículum.  ¡Estamos ansiosos de que formes parte de nuestra gran familia de colaboradores!';
$lang['meta_keywords'] = '';
$lang['meta_title'] = 'Buscando trabajo. Bolsa de trabajo en México y Región Centroamericana';