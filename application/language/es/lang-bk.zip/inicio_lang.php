<?php
$lang['titulo'] = 'Empleos - BAC | Credomatic';
$lang['meta_desc'] = 'BAC Credomatic es un empleador líder en la región que ofrece excelentes condiciones para el desarrollo del talento humano. Conoce nuestros puestos vacantes.';
$lang['meta_keywords'] = 'busco empleo, buscar empleo, vacantes de empleo, empleos, empleador líder, impacto regional, red regional, oportunidades de trabajo, puestos vacantes, México, Centroamérica';
$lang['meta_title'] = 'Vacantes de Empleo. Busco empleo en Centroamérica y México';