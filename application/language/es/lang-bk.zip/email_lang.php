<?php
$lang['-'] = '-';