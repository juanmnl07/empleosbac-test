<?php
$lang['titulo'] = 'Vacantes de Empleo. Busco empleo en Centroamérica y México';
$lang['meta_desc'] = 'BAC Credomatic es un empleador líder en la región que ofrece excelentes condiciones para el desarrollo del talento humano. Conoce nuestros puestos vacantes.';
$lang['meta_keywords'] = 'busco empleo, buscar empleo, vacantes de empleo, empleos, empleador líder, impacto regional, red regional, oportunidades de trabajo, puestos vacantes, México, Centroamérica, desarrollo del talento humano, innovación, inclusión laboral Región, líderes';