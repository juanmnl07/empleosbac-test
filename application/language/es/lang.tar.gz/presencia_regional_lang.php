<?php
$lang['meta_desc'] = 'En BAC/Credomatic tenemos más de 600 sucursales a nivel regional que ofrecen vacantes de trabajo para quienes quieran desarrollarse profesionalmente.';
$lang['meta_keywords'] = 'vacantes de trabajo, puestos de trabajo, oferta de trabajo,  en Centroamérica, México, Región';
$lang['titulo'] = 'Vacantes de trabajo en Centroamérica y México.';